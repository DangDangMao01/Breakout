# Changelog

## [0.23.0] - 2025-08-20
### Added
- Initial release of the add-on.


